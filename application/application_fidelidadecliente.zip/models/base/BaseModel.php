<?php

class BaseModel extends Model {

    function  __construct() {
        parent::Model();
    }

}

?>
